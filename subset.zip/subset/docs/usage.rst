=====
Usage
=====

To use Project Extruder in a project::

    import project_extruder
